#ifndef VTK_READER_H
#define VTK_READER_H

#include "data_structures.h"
#include <vector>

void readVTKFile(int step_number, std::vector<Ponto> &pontos, std::vector<Segmento> &segmentos);

#endif // VTK_READER_H
