#include <GL/freeglut.h>
#include <cmath>
#include <iostream>
#include <vector>
#include <algorithm>
#include "vtk_reader.h"
#include "data_structures.h"

std::vector<Ponto> g_pontos;
std::vector<Segmento> g_segmentos;

float g_transX = 0.0f;
float g_transY = 0.0f;
float g_rotAngulo = 0.0f;
float g_escala = 1.0f;

int g_current_step = 64; // ajuste conforme arquivo existente

// ajuste visual: controla como o raio do arquivo vira largura em NDC
// experimente valores como 0.03f .. 0.15f
float g_globalRadiusScale = 0.05f;

// para normalizar cores
float g_minRaio = 0.0f;
float g_maxRaio = 1.0f;

void init()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // fundo branco como nos exemplos do TP
    glLineWidth(2.0f);
}

// converte um valor v (raio) para cor r,g,b usando um colormap estilo "jet"
void getColorFromValue(float v, float &r, float &g, float &b)
{
    // evita divisão por zero
    float mn = g_minRaio;
    float mx = g_maxRaio;
    float t = 0.0f;
    if (mx > mn)
        t = (v - mn) / (mx - mn);
    t = std::max(0.0f, std::min(1.0f, t));

    // mapa parecido com "jet"
    if (t <= 0.125f)
    {
        // deep blue -> blue
        r = 0.0f;
        g = 0.0f;
        b = 0.5f + (t / 0.125f) * 0.5f;
    }
    else if (t <= 0.375f)
    {
        // blue -> cyan
        float tt = (t - 0.125f) / (0.25f);
        r = 0.0f;
        g = tt;
        b = 1.0f;
    }
    else if (t <= 0.625f)
    {
        // cyan -> green -> yellow
        float tt = (t - 0.375f) / (0.25f);
        r = tt;
        g = 1.0f;
        b = 1.0f - tt;
    }
    else if (t <= 0.875f)
    {
        // yellow -> orange
        float tt = (t - 0.625f) / (0.25f);
        r = 1.0f;
        g = 1.0f - 0.5f * tt;
        b = 0.0f;
    }
    else
    {
        // orange -> red
        float tt = (t - 0.875f) / (0.125f);
        r = 1.0f;
        g = 0.5f - 0.5f * tt;
        b = 0.0f;
    }
}

void drawSegmentAsQuad(const Ponto &a, const Ponto &b, float halfWidth)
{
    float dx = b.x - a.x;
    float dy = b.y - a.y;
    float len = std::sqrt(dx * dx + dy * dy);
    if (len < 1e-6f)
        return;

    float nx = -dy / len;
    float ny = dx / len;

    float ox = nx * halfWidth;
    float oy = ny * halfWidth;

    float v1x = a.x + ox, v1y = a.y + oy;
    float v2x = b.x + ox, v2y = b.y + oy;
    float v3x = b.x - ox, v3y = b.y - oy;
    float v4x = a.x - ox, v4y = a.y - oy;

    glBegin(GL_TRIANGLES);
    glVertex2f(v1x, v1y);
    glVertex2f(v2x, v2y);
    glVertex2f(v3x, v3y);

    glVertex2f(v3x, v3y);
    glVertex2f(v4x, v4y);
    glVertex2f(v1x, v1y);
    glEnd();
}

void updateRadiusRange()
{
    if (g_segmentos.empty())
    {
        g_minRaio = 0.0f;
        g_maxRaio = 1.0f;
        return;
    }
    g_minRaio = g_segmentos[0].raio;
    g_maxRaio = g_segmentos[0].raio;
    for (const auto &s : g_segmentos)
    {
        g_minRaio = std::min(g_minRaio, s.raio);
        g_maxRaio = std::max(g_maxRaio, s.raio);
    }
    // se min == max, expande um pouco para evitar divisão por zero e garantir contraste
    if (std::abs(g_maxRaio - g_minRaio) < 1e-6f)
    {
        float eps = std::max(1e-3f, 0.1f * std::abs(g_minRaio));
        g_minRaio -= eps;
        g_maxRaio += eps;
    }
    std::cout << "Raio range: [" << g_minRaio << ", " << g_maxRaio << "]\n";
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1.5, 1.5, -1.5, 1.5, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glTranslatef(g_transX, g_transY, 0.0f);
    glRotatef(g_rotAngulo, 0.0f, 0.0f, 1.0f);
    glScalef(g_escala, g_escala, 1.0f);

    for (const auto &s : g_segmentos)
    {
        if (s.p1_index < 0 || s.p2_index < 0)
            continue;
        if (s.p1_index >= (int)g_pontos.size() || s.p2_index >= (int)g_pontos.size())
            continue;
        const Ponto &pa = g_pontos[s.p1_index];
        const Ponto &pb = g_pontos[s.p2_index];

        // cor pelo raio
        float rr, gg, bb;
        getColorFromValue(s.raio, rr, gg, bb);
        glColor3f(rr, gg, bb);

        // metade da largura em NDC: raio_do_arquivo * escala_global
        float halfWidth = (s.raio) * g_globalRadiusScale;
        if (halfWidth < 0.0008f)
            halfWidth = 0.0008f;

        drawSegmentAsQuad(pa, pb, halfWidth);
    }

    glutSwapBuffers();
}

void reshape(int w, int h)
{
    glViewport(0, 0, w, h);
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 'w':
        g_transY += 0.05f;
        break;
    case 's':
        g_transY -= 0.05f;
        break;
    case 'a':
        g_transX -= 0.05f;
        break;
    case 'd':
        g_transX += 0.05f;
        break;

    case 'q':
        g_rotAngulo += 5.0f;
        break;
    case 'e':
        g_rotAngulo -= 5.0f;
        break;

    case 'z':
        g_escala += 0.1f;
        break;
    case 'x':
        g_escala = std::max(0.1f, g_escala - 0.1f);
        break;

    case 'r': // reset view
        g_transX = g_transY = 0.0f;
        g_rotAngulo = 0.0f;
        g_escala = 1.0f;
        break;

    case 'K': // aumentar escala de raios (shift+k)
    case 'k':
        g_globalRadiusScale *= 1.2f;
        std::cout << "globalRadiusScale = " << g_globalRadiusScale << std::endl;
        break;
    case 'J': // diminuir escala de raios (shift+j)
    case 'j':
        g_globalRadiusScale /= 1.2f;
        std::cout << "globalRadiusScale = " << g_globalRadiusScale << std::endl;
        break;

    case '+':
        g_current_step = std::min(g_current_step + 8, 512);
        readVTKFile(g_current_step, g_pontos, g_segmentos);
        updateRadiusRange();
        break;

    case '-':
        g_current_step = std::max(g_current_step - 8, 8);
        readVTKFile(g_current_step, g_pontos, g_segmentos);
        updateRadiusRange();
        break;

    case 27:
        exit(0);
        break;
    }

    glutPostRedisplay();
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(800, 800);
    glutCreateWindow("TP1 - Visualização 2D Arterial - Colorido");

    init();

    readVTKFile(g_current_step, g_pontos, g_segmentos);
    updateRadiusRange();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
